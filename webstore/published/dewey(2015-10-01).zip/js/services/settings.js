define(
[
/* No dependencies */
],
function() { "use strict";

return {
  hideTopLevelFolders: false,
  showThumbnails: true
};

});